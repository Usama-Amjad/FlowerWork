# program 1: Print first 10 natural numbers
i = 1
while i <= 10:
    print(i)
    i += 1
